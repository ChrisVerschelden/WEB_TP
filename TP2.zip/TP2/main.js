const cards = document.querySelectorAll('.justify-content-md-start')
const players = document.querySelectorAll('.player-before') 

cards.forEach(e => {
    e.classList.replace('justify-content-md-start', 'justify-content-md-center')
    console.log(e)
})

players.forEach(e => {
    e.classList.replace('player-before', 'player')
    e.classList.add('anim')
    console.log(e)
})